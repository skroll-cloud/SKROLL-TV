# RDV JULIEN APRUZZESE — 1h
## Plan simple

---

## 1. PRÉSENTATION (5 min)

- Bertrand, ex-journaliste France 2, maintenant photographe portraitiste
- Projet EHPAD = soignants invisibles, semaine prochaine
- Projet Médiathèque = diversité créative, couleur
- **Intention : "Faire entrer dans la lumière ce qui est maintenu dans l'ombre"**

---

## 2. MON CHEMINEMENT (10 min)

**Départ** → Setup hyper simple type Platon (fond blanc, tout éclairé)
- Avantage : je me concentre sur la relation, pas la technique
- Problème : pas d'âme, pas de mystère

**Passage Roversi** → Temps long, ombre, flou
- Idée : gens qui passent flous, UN moment net avec flash
- Métaphore : "entrer dans la lumière" = sortir du flou

**Arrivée Vanfleteren / Phil Sharp** → Simplicité apparente
- Humanité, "vieille lumière"
- Intention : mettre en lumière = s'endimancher
- Source unique, soustraction, négatif fill

---

## 3. QUESTIONS PRÉPARATION SÉRIE (15 min)

- **Comment TU prépares une série ?** Repérages ? Tests ? Brief sujets ?
- **Comment faire "série" cohérente ?** (je débute, exercice, pas grave si très référencé)
- **Sujets pas modèles** : fatigués, pas maquillés, pas l'habitude
  → Comment gérer sans trop de post-prod ?

---

## 4. QUESTIONS TECHNIQUES (20 min)

**Matériel :**
- Moyen format vs full frame ? (j'ai Leica SL2-S)
- Numérique ou argentique pour ce rendu ?
- **Rendu doux avec optiques modernes ?** Trop piqué, trop clinique...
- Filtre Black Pro-Mist 1/4 → ton avis ?

**Setup lumière :**
- Grand cadre diffusion + 1/2 Grid Cloth → garder direction ?
- Pas trop de light, travailler par **soustraction** (panneaux noirs)
- Negative fill → V-flat noir suffit ?

**Post-prod :**
- Capture One → tips pour ce rendu N&B ?
- Tethering → conseils pratiques ?
- Comment éditer une série ? Workflow ?

---

## 5. SYNTHÈSE (10 min)

- Ses 3 conseils prioritaires pour EHPAD semaine prochaine
- Erreurs à éviter
- Ce que je peux tester dès maintenant

---

## MOTS-CLÉS À GARDER EN TÊTE

```
SOUSTRACTION > addition
SIMPLICITÉ apparente
HUMANITÉ > technique
TEMPS avec le sujet
DÉTAIL dans les ombres
DIGNITÉ sans embellir
SÉRIE cohérente
```

---

**N'oublie pas : ENREGISTRE LA VISIO**
