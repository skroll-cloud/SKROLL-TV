# BIBLE PORTRAIT
## "Faire entrer dans la lumière ce qui est maintenu dans l'ombre"

*Document évolutif — Bertrand Passet — Carantec*
*Inspiré de "Making Movies" de Sidney Lumet*

---

# SOMMAIRE

1. [L'INTENTION](#1-lintention)
2. [LA PRÉPARATION](#2-la-préparation)
3. [LE MATÉRIEL](#3-le-matériel)
4. [LA LUMIÈRE](#4-la-lumière)
5. [LA DIRECTION DE SUJET](#5-la-direction-de-sujet)
6. [LA PRISE DE VUE](#6-la-prise-de-vue)
7. [LA POST-PRODUCTION](#7-la-post-production)
8. [L'ÉDITION / LA SÉRIE](#8-lédition--la-série)
9. [RÉFÉRENCES](#9-références)
10. [GLOSSAIRE](#10-glossaire)

---

# 1. L'INTENTION

## Ma démarche

> "Faire entrer dans la lumière ce qui est maintenu dans l'ombre"

Cette phrase unifie :
- 20 ans de journalisme documentaire → révéler les invisibles
- Le portrait → donner dignité
- La technique lumière → littéralement faire émerger de l'ombre

## Ce que je ne fais PAS

- Platon : fond blanc, tout éclairé, transparence totale
- Photo corporate classique : éclairage plat, retouche lissante
- Quantité > qualité

## Ce que je fais

- Clair-obscur : le sujet émerge de l'ombre
- Temps long avec la personne
- Textures, marques du temps = dignité, pas défauts
- Série cohérente, pas photos isolées

---

# 2. LA PRÉPARATION

## Avant le shooting

### Repérage
- [ ] Visiter le lieu si possible
- [ ] Identifier sources lumière naturelle (fenêtres, orientation)
- [ ] Mesurer l'espace disponible
- [ ] Repérer prises électriques
- [ ] Identifier fond potentiel ou apporter le sien

### Brief avec les sujets
- [ ] Expliquer la démarche (pas "je vais vous prendre en photo")
- [ ] Durée prévue
- [ ] Tenue : sobre, unie, pas de logos
- [ ] Pas de maquillage spécial (ou minimal)
- [ ] Les mettre à l'aise : "c'est une rencontre"

### Checklist matériel
- [ ] Boîtier + batterie chargée + backup
- [ ] Objectif principal (85mm ou 50mm)
- [ ] Filtre diffusion (Black Pro-Mist 1/4)
- [ ] Flash + câble sync ou trigger
- [ ] Lampe pilote vérifiée
- [ ] Cadre diffusion + toile
- [ ] Panneaux noirs (V-flat ou drapeaux)
- [ ] Pieds lumière
- [ ] Fond si nécessaire
- [ ] Posemètre (optionnel si tethering)
- [ ] Ordi + câble tethering
- [ ] Cartes mémoire formatées

---

# 3. LE MATÉRIEL

## INVENTAIRE COMPLET

### Boîtiers

| Modèle | Batteries | Notes |
|--------|-----------|-------|
| Leica SL2-S | 3 | Boîtier principal portrait |
| Leica Q3 | 1 | Compact, 28mm fixe |

### Optiques

| Objectif | Ouverture | Monture | Ø filtre | Usage |
|----------|-----------|---------|----------|-------|
| Voigtlander 35mm | f/2 | M (avec bague) | 49mm | Environnement |
| Sigma 50mm | f/1.2 | L | 72mm | Portrait serré, bokeh |
| Lumix 85mm | f/1.8 | L | 67mm | Portrait classique |

### Filtres & Accessoires optiques

| Élément | État/Notes |
|---------|------------|
| Tilta Mirage | ND variable cassé |
| Step-up rings | 55→58, 58→62, 62→67, 67→72 |
| Prisme DIY | Effets créatifs |

**À ACHETER :** Filtre diffusion (Pro-Mist 1/4 ou Cinebloom) en 72mm ou 67mm

### Déclenchement

| Modèle | Compatibilité |
|--------|---------------|
| Godox X3 | Leica |
| Godox XPro2 | Multi |

### Éclairage Flash

| Modèle | Puissance | Lampe pilote | Notes |
|--------|-----------|--------------|-------|
| Godox AD600 Pro | 600Ws | 38W LED, 4800K | Principal portrait |
| Godox AD100 Pro | 100Ws | Oui | Compact, modifiers Profoto |

### Éclairage Continu

| Modèle | Type | Notes |
|--------|------|-------|
| Aputure 120D MK2 | COB daylight | ~1300 lux à 1m |
| Aputure LS1C | Panel bicolore | Réglable 3200-5600K |
| Nanlite Tube 1m | LED tube | Effets, accent |

### Modeleurs de lumière

| Élément | Taille | Compatible avec |
|---------|--------|-----------------|
| Parapluie Profoto L blanc + diffuseur | 130cm | Flash |
| Parapluie Profoto M translucide | 105cm | Flash |
| Fresnel Aputure | - | 120D |
| Dome Light 2 Aputure | - | 120D |
| Snoot | - | Flash |
| Strip box Aputure | 30×120cm | 120D |
| Softbox Aputure + grille | 80×80cm | 120D |

### Pieds & Grip

| Élément | Quantité |
|---------|----------|
| Manfrotto 1004BAC | 3 |
| Pieds légers | 2-3 |
| Pinces diverses | Quelques-unes |
| Pied Peak Design (voyage) | 1 |

**À ACHETER :** Negative fill (V-flat noir ou Floppy)

### Fonds

| Type | Dimensions | Notes |
|------|------------|-------|
| Support Manfrotto | 4×2.3m (3 sections) | Pliable |
| Fond noir | - | Portrait N&B |
| Fond moucheté gris/noir | - | Texture |
| Fond vert | - | Incrustation |

### Tissus

| Couleur | Matière |
|---------|---------|
| Blanc | Draps |
| Bordeaux | Coton qualité |
| Olive | Coton qualité |
| Vert bouteille | Coton qualité |
| Terracotta | Coton qualité |

### Gélatines & Divers

- Quelques gélatines (couleurs à préciser)
- Modifiers Profoto pour AD100 Pro

---

## Filtres diffusion objectif (À ACHETER)

| Filtre | Effet | Usage |
|--------|-------|-------|
| Tiffen Black Pro-Mist 1/4 | Léger halo hautes lumières, adoucit | Standard portrait |
| Tiffen Glimmerglass 1 | Plus subtil que Pro-Mist | Julien utilise |
| Cinebloom 10% | Blooming organique | Alternative moderne |

**Règle :** Ne jamais laisser l'objectif "pur" — toujours filtrer pour casser la netteté digitale.

**Décision :** Quel objectif pour EHPAD ? → Diamètre filtre à acheter

---

# 4. LA LUMIÈRE

## Les 3 seuls paramètres à maîtriser

> "Tous les plus grands chefs opérateurs au monde, c'est la seule chose qu'ils doivent faire"
> — Julien Apruzzese

### 1. TAILLE APPARENTE

**Ce n'est PAS la taille physique de ta source.**

C'est la taille perçue depuis le sujet.

**Test :** Place-toi au niveau du sujet, regarde ta source, pince-la avec tes doigts. Cette taille = ta taille effective.

- Softbox 1m à 3m de distance = peut-être 30cm effectifs
- Softbox 1m à 50cm = presque 1m effectifs

**Règle :** Lumière douce = source GRANDE et PROCHE

### 2. DISTANCE

La distance affecte :
- La taille apparente (voir ci-dessus)
- Le fall-off (vitesse de dégradé lumière → ombre)
- Source proche = fall-off rapide (variations intenses)
- Source loin = fall-off lent (lumière plus uniforme)

### 3. DIRECTION

- **Frontale** : peu d'ombres, "plat"
- **Latérale 45°** : classique, modèle le visage
- **Latérale 90°** : split lighting, dramatique
- **Zénithale** : "entrée dans la lumière", ombres sous nez/yeux
- **Contre-jour** : silhouette ou rim light

## Short Light vs Broad Light

| Type | Description | Mood |
|------|-------------|------|
| **Broad light** | + de surface éclairée que d'ombre | Comédie, léger, accessible |
| **Short light** | + de surface d'ombre que d'éclairé | Thriller, suspense, dramatique |

**Pour mon projet EHPAD :** Short light = cohérent avec "émerger de l'ombre"

## La diffusion — Comprendre vraiment

### Ce que la diffusion fait
- Agrandit la taille de la source PAR PROJECTION
- La nouvelle source démarre au niveau du diffuseur

### Ce que la diffusion ne fait PAS
- Adoucir magiquement la lumière
- Un diffuseur collé au flash = même dureté, juste perte de puissance

### Règle pratique
- Distance flash → diffuseur = contrôle la taille du cercle projeté
- Distance diffuseur → sujet = ta vraie distance de travail
- Si flash à 1m du diffuseur, cercle ≈ 1.5m sur le cadre
- Si flash collé au diffuseur, cercle = taille du flash

### Grid Cloth 1/2
- Avantage : garde la direction de la lumière (pas trop de spill)
- Permet de créer une grande source douce MAIS directionnelle

## Travailler par soustraction

> "Pour chaque instrument qui crée de la lumière, un instrument qui coupe la lumière"

- Panneaux noirs (V-flat, drapeaux, duvetyne)
- Couper le spill indésirable
- Créer le contraste
- Approche Lindbergh : "subtractive lighting"

## Lampe pilote — Règles

1. **Toujours allumée** — elle s'éteint automatiquement au flash
2. **Mode FIXE à 100%** (pas proportionnel) pour autofocus
3. **Pas de lumière continue en plus** — pollue l'image
4. Attention : sur petits flashs, lampe pilote décalée = léger parallaxe

---

# 5. LA DIRECTION DE SUJET

## Sujets non-modèles

- Ils ne savent pas poser → c'est une force (authenticité)
- Leur parler pendant la prise
- Micro-ajustements : "avance le menton", "tourne légèrement"
- Quelques cm changent tout (surtout source proche)

## Gérer la fatigue

- Sessions courtes (15-20 min max par personne)
- Pauses
- Chaise/tabouret disponible
- Ambiance calme, pas de stress

## Pas de maquillage — Gérer les peaux

- La lumière fait 80% du travail
- Source grande et proche = transitions douces
- Éviter lumière dure directe sur peaux à problèmes
- Le reste = post-prod subtile (pas lisser, juste harmoniser)

---

# 6. LA PRISE DE VUE

## Réglages de base

| Paramètre | Valeur | Pourquoi |
|-----------|--------|----------|
| ISO | 100-400 | Qualité max, peu de bruit |
| Ouverture | f/2.8-4 | Douceur naturelle, sujet détaché |
| Vitesse | 1/125-1/250 | Sync flash, net |
| Format | RAW | Obligatoire |

## Tethering

### Pourquoi
- Voir immédiatement le résultat en grand
- Histogramme pré-traitement (Capture One)
- Ajuster en temps réel
- Le sujet peut voir (crée de la complicité)

### Exposition optimale (technique avancée)
1. Regarder histogramme **pré-traitement** dans Capture One
2. Monter l'expo au maximum avant écrêtage
3. En post : rebaisser pour l'expo artistique souhaitée
4. = Meilleur rapport signal/bruit

## Autofocus en basse lumière

Problème : dans le noir, l'AF ne sait pas où aller.

Solutions :
1. Lampe pilote à 100% (mode fixe)
2. Mise au point sur l'œil
3. Si échec : AF ponctuel sur zone contrastée, recadrer

---

# 7. LA POST-PRODUCTION

## Philosophie

> "C'est 50/50. Tout ne peut pas se faire à la lumière. Ceux qui disent le contraire sont des mythos."
> — Julien Apruzzese

Le but : retrouver la douceur argentique que le digital ne donne pas nativement.

---

## CAPTURE ONE — Réglages de base

### À l'ouverture d'un fichier

| Paramètre | Valeur par défaut | Ce qu'il faut faire |
|-----------|-------------------|---------------------|
| Netteté (Sharpening) | 120 | **METTRE À ZÉRO** |
| Clarté | 0 | Ne pas toucher (ou +0 à +20 max) |
| Structure | 0 | Baisser entre -10 et -20 |

### Pourquoi
Le fichier digital est nativement trop net. Il faut casser cette netteté pour retrouver un rendu organique.

---

## PHOTOSHOP — Tuto pas à pas : Le hack argentique

### Ce qu'on va faire
1. Flouter légèrement l'image
2. Créer un grain couleur
3. Matcher les deux pour que ça fusionne

### Principe fondamental

> "Le point le plus net de l'image ne peut pas être plus net que le grain lui-même — c'est le grain qui fait l'image en argentique"

---

### ÉTAPE 1 : Ouvrir l'image

1. Dans Capture One : clic droit sur l'image → **Modifier avec** → **Photoshop**
2. L'image s'ouvre dans Photoshop

---

### ÉTAPE 2 : Préparer le calque image

1. Dans le panneau **Calques** (à droite), tu vois ton image ("Arrière-plan")
2. **Clic droit** sur ce calque → **Dupliquer le calque** → OK
3. Tu as maintenant "Arrière-plan copie"
4. **Clic droit** sur "Arrière-plan copie" → **Convertir en objet dynamique**
   - Ça permet de revenir modifier le flou après

---

### ÉTAPE 3 : Flouter l'image

1. Vérifie que "Arrière-plan copie" est sélectionné (surligné en bleu)
2. Menu : **Filtre** → **Flou** → **Flou gaussien...**
3. Une fenêtre s'ouvre avec un curseur "Rayon"
4. **Valeur : entre 1.0 et 2.0 pixels**
   - 1.0 = léger
   - 2.0 = plus prononcé
   - Ça dépend de la définition de ton image
5. Clique **OK**

**Astuce :** Tu peux cocher/décocher "Aperçu" pour voir avant/après

---

### ÉTAPE 4 : Créer le calque pour le grain

1. Menu : **Calque** → **Nouveau** → **Calque...** → OK
   - Un nouveau calque vide apparaît ("Calque 1")
2. On va le remplir de gris 50% :
   - Menu : **Édition** → **Remplir...**
   - Dans "Contenu", choisis **50% gris**
   - Clique **OK**
   - Ton image devient toute grise (c'est normal)

---

### ÉTAPE 5 : Passer le calque gris en mode Incrustation

1. Dans le panneau Calques, trouve "Calque 1" (le gris)
2. En haut du panneau, il y a un menu déroulant qui dit "Normal"
3. Clique dessus → choisis **Incrustation**
4. **Magie :** le gris disparaît, tu revois ton image !
   - Le mode Incrustation rend le 50% gris invisible

---

### ÉTAPE 6 : Convertir en objet dynamique

1. **Clic droit** sur "Calque 1" → **Convertir en objet dynamique**
   - Permet de modifier le grain après

---

### ÉTAPE 7 : Ajouter le bruit (grain)

1. Vérifie que "Calque 1" est sélectionné
2. Menu : **Filtre** → **Bruit** → **Ajout de bruit...**
3. Dans la fenêtre :
   - **Quantité** : entre 5% et 15% (commence à 8%)
   - **Répartition** : Gaussienne
   - **⚠️ IMPORTANT : DÉCOCHE "Monochromatique"**
     - On veut du grain COULEUR, pas gris
4. Clique **OK**

---

### ÉTAPE 8 : Désaturer légèrement le grain

Le grain est trop coloré, on va l'atténuer :

1. Calque 1 toujours sélectionné
2. Menu : **Image** → **Réglages** → **Teinte/Saturation...**
3. Baisse le curseur **Saturation** vers la gauche
   - Valeur : entre -30 et -60 (à l'œil)
   - Le grain doit rester légèrement coloré, pas gris
4. Clique **OK**

---

### ÉTAPE 9 : Flouter le grain

C'est l'étape clé — le grain doit être aussi "flou" que l'image.

1. Calque 1 sélectionné
2. Menu : **Filtre** → **Flou** → **Flou gaussien...**
3. **Valeur : généralement DIFFÉRENTE de l'image**
   - Souvent entre 0.5 et 1.5 pixels
   - L'objectif : que le grain et l'image aient la même "texture"
4. **Compare visuellement :**
   - Zoome à 100% sur un œil ou un cil
   - Le cil doit être aussi net/flou que le grain autour
   - Ajuste jusqu'à ce que ça "matche"
5. Clique **OK**

---

### ÉTAPE 10 : Affiner (optionnel)

Tu peux revenir sur n'importe quel réglage :

- Double-clic sur "Flou gaussien" sous le calque → modifie la valeur
- Double-clic sur "Ajout de bruit" → modifie la quantité

---

### ÉTAPE 11 : Finaliser

Quand tu es satisfait :

1. **Clic droit** sur chaque calque objet dynamique → **Pixelliser le calque**
   - Ça "grave" les effets et allège le fichier
2. Menu : **Calque** → **Aplatir l'image**
3. Menu : **Fichier** → **Enregistrer**
4. Ferme Photoshop → retour dans Capture One avec l'image modifiée

---

### RÉSUMÉ VISUEL

```
┌─────────────────────────────────────────┐
│  CALQUE 1 (Grain)                       │
│  - Mode : Incrustation                  │
│  - Bruit : 8%, NON monochromatique      │
│  - Saturation : -40                     │
│  - Flou gaussien : 0.8px                │
├─────────────────────────────────────────┤
│  ARRIÈRE-PLAN COPIE (Image)             │
│  - Flou gaussien : 1.5px                │
├─────────────────────────────────────────┤
│  ARRIÈRE-PLAN (Original)                │
│  - Intact, sécurité                     │
└─────────────────────────────────────────┘
```

---

### CHECKLIST RAPIDE

- [ ] Capture One : Netteté à 0
- [ ] Capture One : Structure -10 à -20
- [ ] Photoshop : Dupliquer + objet dynamique
- [ ] Photoshop : Flou gaussien image 1-2px
- [ ] Photoshop : Nouveau calque 50% gris
- [ ] Photoshop : Mode Incrustation
- [ ] Photoshop : Bruit NON monochromatique 5-15%
- [ ] Photoshop : Désaturer grain -30 à -60
- [ ] Photoshop : Flou gaussien grain (matcher avec image)
- [ ] Vérifier : cil aussi net/flou que le grain
- [ ] Aplatir et sauvegarder

---

## N&B — Workflow spécifique

*(À compléter)*

---

# 8. L'ÉDITION / LA SÉRIE

## Faire série

- Cohérence lumière sur tous les portraits
- Même setup de base (ajustements mineurs OK)
- Même post-prod appliquée
- Sélection : garder les images qui "parlent ensemble"

## Quantité

- Série portrait : 10-15 images finales
- Shooting : probablement 50-100 prises
- Sélection sévère

*(À développer avec l'expérience)*

---

# 9. RÉFÉRENCES

## Photographes

### Stephan Vanfleteren (Belgique)
- **Style :** Clair-obscur, "vieille lumière", portraits intemporels
- **Matériel :** Hasselblad H4D-40, anciennement Rolleiflex
- **Lumière :** 90% naturelle, fenêtre nord, jours nuageux
- **Citation :** "I only have two lights. The simpler it looks, the harder it is."
- **Livre :** Atelier (2023)
- **Site :** stephanvanfleteren.com

### Lee Jeffries (UK)
- **Style :** Portraits SDF, dignité des invisibles
- **Matériel :** Canon 5D, 70-200mm
- **Lumière :** Naturelle + petit réflecteur, dodge & burn intense
- **Citation :** "Everyone else walks by like they are invisible. I'm stepping through the fear."
- **Site :** lee-jeffries.co.uk

### César Viera (Espagne)
- **Style :** Low-key extrême, obsession ombres et textures
- **Technique :** Source unique latérale 45°, AUCUN fill, negative fill total
- **Instagram :** @cesarviera_photography

### Peter Lindbergh (Allemagne)
- **Style :** Réalisme brut, anti-retouche
- **Technique :** "Subtractive lighting", "black tent"
- **Citation :** "Libérer les femmes de la terreur de la perfection"
- **Matériel :** Mamiya RZ67, 90-150mm

### Paolo Roversi (Italie/Paris)
- **Style :** Évanescence, intimité
- **Technique :** Polaroid 8x10, Mag-Lite en pose longue
- **Matériel :** Deardorff 8x10, Goerz 360mm toujours ouvert
- **Citation :** "La photo n'est pas une représentation, c'est une rencontre"

### Martin Schoeller (Allemagne/USA)
- **Style :** Portraits hyper-détaillés, fond uni, identité reconnaissable
- **Technique :** 2 strips de part et d'autre objectif + lumière fond dégradé
- **Note :** Assistant d'Annie Leibovitz
- **À étudier pour :** Setup multi-lumières maîtrisé

### Phil Sharp (UK)
- **Style :** Portraits intimes, lumière douce, navigation image pure
- **Site :** philsharp.co.uk
- **À étudier pour :** Simplicité apparente, couleur désaturée

### Sebastião Salgado (Brésil)
- **Style :** Travailleurs, dignité du labeur, N&B épique
- **Livre :** Workers
- **À étudier pour :** Séries documentaires au long cours

## Livres

- **Atelier** — Stephan Vanfleteren (2023)
- **Present** — Stephan Vanfleteren (2019)
- **A Different Vision on Fashion Photography** — Peter Lindbergh
- **Workers** — Sebastião Salgado
- **Making Movies** — Sidney Lumet (structure de cette bible)

## Formations / Consultants

- **Julien Apruzzese** — Conseil lumière & post-prod (150€/h visio)

---

# 10. GLOSSAIRE

| Terme | Définition |
|-------|------------|
| **Broad light** | Plus de surface éclairée que d'ombre (mood léger) |
| **Short light** | Plus d'ombre que de lumière (mood dramatique) |
| **Fall-off** | Vitesse de transition lumière → ombre |
| **Negative fill** | Panneau noir pour absorber la lumière, creuser les ombres |
| **Taille apparente** | Taille perçue de la source depuis le sujet (≠ taille physique) |
| **Lampe pilote** | Lumière continue du flash pour voir/faire le point (s'éteint au déclenchement) |
| **Tethering** | Connexion boîtier → ordi pour voir les images en direct |
| **Grid Cloth** | Toile de diffusion qui garde la direction de la lumière |
| **Flou gaussien** | Type de flou doux et uniforme (Photoshop) |
| **Objet dynamique** | Calque Photoshop modifiable après coup |
| **Mode Incrustation** | Mode de fusion qui rend le 50% gris invisible |

---

# NOTES & AJOUTS

*(Espace pour ajouter des découvertes, tests, retours d'expérience)*

---

**Dernière mise à jour :** Février 2026
**Prochaine session prévue :** Shooting EHPAD (semaine prochaine)

