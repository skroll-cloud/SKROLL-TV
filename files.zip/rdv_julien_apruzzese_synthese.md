# RENDEZ-VOUS CONSEIL — JULIEN APRUZZESE
## Synthèse des références, questions et sujets à aborder
### Préparation 1h — 150€

*Document préparé pour Bertrand Basset — Février 2026*

---

# 1. INTENTION ARTISTIQUE GLOBALE

## "Faire entrer dans la lumière ce qui est maintenu dans l'ombre"

Cette phrase-clé unifie tout ton travail :
- 20 ans de journalisme documentaire → révéler des sujets invisibles
- Portraits GEM (santé mentale) → dignité des oubliés
- Série EHPAD → valoriser les soignants invisibles
- Médiathèque → célébrer la diversité créative

**La lumière devient littérale dans le setup :**
- Fond noir/sombre = l'ombre, l'invisibilité
- Keylight sculptée = la révélation, la dignité
- Le personnage entre activement dans la lumière

**≠ Platon** (fond blanc, lumière partout, "tout révélé")  
**= Caravage/Vanfleteren/Roversi** (contraste, clair-obscur, émergence)

---

# 2. LES DEUX PROJETS PRIORITAIRES

## A. PROJET EHPAD — Priorité immédiate (semaine prochaine)

### Intention
Portraits de soignants et résidents — Révéler la dignité des "invisibles du soin"

### Esthétique visée
- **N&B dramatique** style Vanfleteren
- Lumière latérale sculptée (45-90°)
- Negative fill prononcé
- Textures maximisées (mains, visages marqués par le temps)
- Fond noir ou très sombre

### Références principales

| Photographe | Ce qu'on retient | Lien |
|-------------|------------------|------|
| **Stephan Vanfleteren** | "Vieille lumière", chiaroscuro, 12 ans d'observation lumière naturelle | stephanvanfleteren.com |
| **César Viera** | Low-key extrême, obsession symétrie + textures, "amoureux des ombres" | @cesarviera_photography |
| **Peter Lindbergh** | Authenticité, refus retouche, humanité dans la mode | Livre "A Different Vision" |

### Setup envisagé
```
┌─────────────────────────────────────────┐
│                                         │
│  [Cadre 2.2m + 1/2 Grid Cloth]          │
│  (Aputure 120D ou AD600 derrière)       │
│         ↘ 45°                           │
│                                         │
│  [V-Flat noir] ← SUJET → [Fond noir]    │
│   negative fill                         │
│                                         │
│              📷 SL2-S                   │
│                                         │
└─────────────────────────────────────────┘
```

### Questions techniques pour Julien
1. **Ratio lumière/ombre** : Quel ratio pour garder détail dans ombres sans fill ?
2. **Distance source/sujet** : À quelle distance placer le cadre diffusé pour fall-off optimal ?
3. **Puissance flash vs continu** : AD600 Pro ou Aputure 120D pour ce style ?
4. **Negative fill efficace** : V-Flat noir suffit ou faut-il duvetyne + drapeaux ?
5. **Gestion espace contraint EHPAD** : Comment adapter si pièce petite/plafonds bas ?
6. **Post-production N&B** : Workflow Capture One pour contraste Vanfleteren ?

---

## B. PROJET MÉDIATHÈQUE — À venir

### Intention
Portraits des usagers/équipes de médiathèque — Célébrer la diversité et la créativité

### Esthétique visée
- **Couleur désaturée** style Phil Sharp
- Lumière plus enveloppante, frontale/légèrement latérale
- Tons chauds, ambiance accessible
- Fond neutre ou contextuel (rayonnages flous ?)

### Référence principale

| Photographe | Ce qu'on retient | Lien |
|-------------|------------------|------|
| **Phil Sharp** | Portraits intimes, lumière douce enveloppante, navigation image pure | philsharp.co.uk |

### Setup envisagé
- Source plus grande, plus proche
- Fill léger (réflecteur blanc ou 2e source faible)
- Moins de contraste que EHPAD
- Couleur travaillée en désaturation partielle

### Questions pour Julien (si temps)
1. **Différence setup couleur vs N&B** : Mêmes sources, traitement différent ?
2. **Lumière frontale douce** : Octobox vs cadre diffusé ?
3. **Gestion arrière-plan contextuel** : Comment flouter sans perdre le sens du lieu ?

---

# 3. RÉFÉRENCES PHOTOGRAPHES ÉTUDIÉES

## A. STEPHAN VANFLETEREN (Belgique)
**Style :** Clair-obscur, "vieille lumière", portraits intemporels

### Ce qu'on sait
- **Matériel** : Hasselblad H4D-40, anciennement Rolleiflex SL66
- **Lumière** : 90% naturelle (fenêtre nord, jours nuageux)
- **Citation clé** : *"I only have two lights. The simpler it looks, the harder it is."*
- **Fond** : Rideaux gris théâtre, variation naturelle
- **Post-prod** : Contraste maîtrisé, détails préservés dans ombres
- **Philosophie** : Patience (12 ans à observer la lumière dans son atelier)

### Technique spécifique
- ISO 400, f/4, ~1/350 sec (données EXIF World Press Photo)
- Temps de pose "modéré" = visage net, micro-mouvements mains = humanité
- Negative fill avec réflecteur noir, pas de fill actif

---

## B. PAOLO ROVERSI (Italie/Paris)
**Style :** Évanescence, intimité, Polaroid signature

### Ce qu'on sait
- **Matériel** : Chambre Deardorff 8x10, objectif Goerz 360mm f/6.8 (toujours ouvert)
- **Lumière** : Fenêtre + technique Mag-Lite (lampe torche en pose longue)
- **Film** : Polaroid 8x10 "Chocolate" (mélange néga couleur + positif N&B)
- **Citation clé** : *"La photo n'est pas une représentation de la réalité, c'est une rencontre."*
- **Philosophie** : Lenteur, hasard, connexion profonde avec le sujet

### Technique Mag-Lite (à tester)
- Studio noir complet
- Pose 2-10 secondes
- Lampe torche déplacée rapidement = "pinceau de lumière"
- Résultat : lumière sculptée, évanescente

---

## C. PETER LINDBERGH (Allemagne/NYC)
**Style :** Réalisme brut, anti-retouche, humanité

### Ce qu'on sait
- **Matériel** : Mamiya RZ67, Hasselblad, focales 90-150mm
- **Lumière** : "Subtractive lighting" — enlever de la lumière plutôt qu'en ajouter
- **Technique** : "Black tent" = tente noire autour du sujet, une seule ouverture
- **Citation clé** : *"C'est la responsabilité des photographes de libérer les femmes de la terreur de la perfection."*
- **Philosophie** : Refus retouche, fascination pour la "géographie des visages"

### Applicable EHPAD
- Approche minimaliste (1 source, drapeaux noirs)
- Valoriser rides, marques du temps
- Refuser l'embellissement artificiel

---

## D. MARK MANN (Écosse/NYC)
**Style :** Portraits célébrités, ring light signature, intimité

### Ce qu'on sait
- **Matériel** : Leica S-System + 120mm, Leica M + 50mm
- **Lumière** : Rotolight Anova LED (continu), ring light carré (4 Blade 10)
- **Citation clé** : *"The mood comes from shaping the light. I create a space where the subject can move and still be lit correctly."*
- **Philosophie** : Simplicité, confort du sujet (LED = pas de chaleur)

### Technique
- Souvent 1-2 sources seulement
- Continuous LED = voir la lumière en temps réel
- Ring light frontal = catchlight circulaire ou carré signature

---

## E. CÉSAR VIERA (Madrid)
**Style :** Low-key extrême, obsession ombres et textures

### Ce qu'on sait
- **Approche** : Autodidacte, premier appareil à 32 ans
- **Signature** : Symétrie + textures peau = valeur au passage du temps
- **Citation clé** : *"J'utilise la photo pour laisser échapper mon côté obscur, une mirada cruda de la vida."*
- **Enseignement** : Workshops "fotografía en clave baja"

### Technique probable (déduite visuellement)
- Source unique latérale 45°, légèrement haute
- Aucun fill — negative fill total
- Grid ou strip box pour contrôle du spill
- Fond noir absolu

---

## F. PLATON (Grèce/NYC)
**Style :** Portraits pouvoir, fond blanc, lumière directe

### Pourquoi l'opposé de ta démarche
- Fond blanc = tout est révélé, pas de mystère
- Lumière partout = transparence totale
- Convient pour leaders politiques, "accountability"
- **≠ Ton approche** : tu révèles en faisant émerger de l'ombre

---

# 4. MATÉRIEL EXISTANT

| Équipement | Usage prévu |
|------------|-------------|
| **Leica SL2-S** | Boîtier principal |
| **Aputure 120D Mark II** | LED continue, derrière cadre diffusé |
| **Godox AD600 Pro** | Flash si besoin puissance |
| **Cadres Manfrotto** | 1.1m×2.3m (×2), 2.8m×2.3m |
| **Pieds** | 3 lourds, 2-3 légers |

### Manques identifiés (liste La BS ~560€)
- Super Clamps (×4)
- Bras magiques (×2)
- Spigots/adaptateurs
- Drapeaux/Floppies noirs
- Gaffer noir mat

### Achats prévus
- **1/2 Grid Cloth** (80-150€) — priorité absolue
- **Duvetyne noir** 3m×2m (40-60€)
- **Carton plume noir** DIY V-Flats (30€)
- **Tiffen Black Pro-Mist 1/4** 82mm (100-150€)

---

# 5. QUESTIONS TECHNIQUES PRIORITAIRES

## A. Lumière & Setup (EHPAD)

1. **Configuration source unique** : Comment obtenir le fall-off progressif Vanfleteren avec mon matériel ?

2. **Ratio highlight/shadow** : Quel ratio pour garder du détail dans les ombres sans remplir ?

3. **Distance optimale** : À quelle distance placer le cadre 2.2m + 1/2 Grid Cloth du sujet ?

4. **Negative fill** : V-Flat noir DIY suffit ou faut-il drapeaux pro + duvetyne ?

5. **Flash vs LED** : Pour ce style, AD600 Pro (flash) ou Aputure 120D (continu) ?

## B. Gestion contraintes terrain

6. **Espace limité** : Adapter le setup dans une chambre EHPAD (3×4m, plafonds bas) ?

7. **Temps court** : Workflow efficace si seulement 15-20 min par personne ?

8. **Sujets fragiles** : Conseils pour photographier personnes âgées (fatigue, mobilité) ?

## C. Post-production

9. **Workflow N&B** : Capture One ou Lightroom ? Réglages clés pour contraste Vanfleteren ?

10. **Peau et textures** : Comment maximiser les textures sans faire "sale" ?

---

# 6. QUESTIONS ARTISTIQUES / MÉTHODOLOGIQUES

1. **Cohérence série** : Comment garantir unité visuelle sur 10-15 portraits étalés ?

2. **Interaction sujet** : Diriger ou laisser faire ? Parler pendant la prise de vue ?

3. **Choix du "bon" moment** : Comment reconnaître LA photo dans une séquence ?

4. **Équilibre dignité/vérité** : Montrer les marques du temps sans "misérabilisme" ?

5. **Feedback ta série GEM** : (si tu montres des images) Qu'est-ce qui fonctionne/ne fonctionne pas ?

---

# 7. IMAGES À MONTRER (optionnel)

Si tu veux un feedback concret :
- 2-3 portraits de ta série GEM (les plus réussis)
- 2-3 portraits de ta série GEM (ceux qui te posent problème)
- Ton setup actuel (photo du studio/matériel)

---

# 8. PLANNING SUGGÉRÉ DE L'HEURE

| Durée | Contenu |
|-------|---------|
| **5 min** | Contexte : qui tu es, ta démarche "faire entrer dans la lumière" |
| **5 min** | Montrer références (Vanfleteren, Viera, Lindbergh) + intention EHPAD |
| **25 min** | **EHPAD** : questions techniques, feedback setup, conseils terrain |
| **10 min** | Médiathèque : différences couleur/N&B, approche Phil Sharp |
| **10 min** | Questions ouvertes artistiques/méthodologiques |
| **5 min** | Synthèse, recommandations prioritaires |

---

# 9. CE QUE TU VEUX RESSORTIR AVEC

## Minimum vital
- [ ] Validation ou correction de ton setup lumière EHPAD
- [ ] 2-3 conseils concrets applicables dès la semaine prochaine
- [ ] Réponse à "flash ou LED ?" pour ce style

## Bonus si temps
- [ ] Feedback sur images GEM existantes
- [ ] Workflow post-prod recommandé
- [ ] Différences setup couleur (Médiathèque) vs N&B (EHPAD)

---

# 10. LIENS UTILES À AVOIR SOUS LA MAIN

- **Vanfleteren** : stephanvanfleteren.com
- **César Viera** : instagram.com/cesarviera_photography
- **Phil Sharp** : philsharp.co.uk
- **Mark Mann** : markmannphoto.com
- **Roversi** : paoloroversi.com
- **Lindbergh** : peterlindbergh.com

---

*Document préparé par Claude — Enregistre la visio pour revenir sur les conseils*
